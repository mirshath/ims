# sktbuilder_default_blocks
Default blocks for sktbuilder plugin
