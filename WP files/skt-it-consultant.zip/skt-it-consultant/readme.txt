/*-----------------------------------------------------------------------------------*/
/* It Consultant Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   SKT IT Consultant
Theme URI       :   https://www.sktthemes.org/shop/consultant-lite/
Version         :   1.6
Tested up to    :   WP 5.2
Author          :   SKT Themes
Author URI      :   https://www.sktthemes.org/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - All js that have been used are within folder /js of theme.
- jquery.nivo.slider.js is licensed under MIT.

2 - PT Sans font - https://www.google.com/fonts/specimen/PT+Sans
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html


3 -  Slider Images - 
	http://pixabay.com/en/man-one-of-the-happy-korean-449404/
	http://pixabay.com/en/executive-businesswoman-532448/
	http://pixabay.com/en/career-man-career-ladder-silhouette-111932/

For any help you can mail us at support[at]sktthemes.com