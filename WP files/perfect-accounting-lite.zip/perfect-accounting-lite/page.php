<?php 
/**
 * The Default Page Template for Perfect Accounting Lite
 *
 * Displays the Pages.
 *
 * @package Perfect Accounting Lite
 * 
 * @since SKT Perfect Accounting Lite 1.0
 */
global $complete;?>

<?php get_header(); ?>
    <div class="page_wrap layer_wrapper">
     <?php if (!is_front_page()) { ?>
        <!--CUSTOM PAGE HEADER STARTS-->
            <?php get_template_part('sktframe/core','pageheader'); ?>
        <!--CUSTOM PAGE HEADER ENDS-->
        <?php } ?>
<?php if ( is_front_page() || is_home() ) { ?>        
        <div class="fixed_site layer_wrapper">
  <div class="fixed_wrap fixindex"> 
  
<!-- Featture Boxes Section Start -->
    <div class="featured_area <?php if($complete['homeblock_bg_setting']){ ?>featured_area_bg<?php } ?> <?php if(!empty($complete['hide_boxes'])){ echo 'hide_section';} ?>" <?php if(!empty($complete['ftd_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $ftdbgvideo = $complete['ftd_bg_video']; echo do_shortcode($ftdbgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
      <div class="center">
        <div class="sectionrow">
<?php
$pages = array();
for ( $count = 1; $count <= 4; $count++ ) {
	$mod = get_theme_mod( 'featuredpage-setting' . $count );
	if ( 'page-none-selected' != $mod ) {
		$pages[] = $mod;
	}
}
$filterArray = array_filter($pages);
if(count($filterArray) == 0){ ?>
<?php
for($bx=1; $bx<4; $bx++) { ?>
<div class="featured_block fblock3 <?php if($bx%3==0){ ?>no_margin_padding_right<?php } ?>">
<div class="featuredinfomain">
 	<div class="featured-thumb"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/featured_icon<?php echo esc_attr($bx); ?>.png"></div>
    <div class="featured-cont-box">
    	<h3><?php echo 'ACCOUNTING';?></h3>
        <p><?php echo 'Donec mauris ligula, dictum sit amet aliquet et, maximus a diam. Morbi nec condimentum quam. In posuere, mi quis congue aliquam, mi diam posuere diam';?></p>
         <a href="<?php echo esc_url('#');?>" class="sktmore"><?php echo 'Read More';?></a>
        </div>
</div>
</div>
	
<?php } ?>                    
<?php 	
}else{

$filled_array=array_filter($pages);
$classNo = count($filled_array);	
	
$args = array(
	'posts_per_page' => 3,
	'post_type' => 'page',
	'post__in' => $pages,
	'orderby' => 'post__in'
);

$query = new WP_Query( $args );
if ( $query->have_posts() ) :
	$count = 1;
	while ( $query->have_posts() ) : $query->the_post();
	?>
	<div class="featured_block <?php echo 'fblock'.$classNo; if($count % $classNo == 0){ ?> no_margin_padding_right<?php } ?>">
<div class="featuredinfomain">
	<?php if(!empty($complete['featuredpage-setting'.$count.'_image']['url'])){   ?>
    <div class="featured-thumb">
    <img src="<?php $pgimg = $complete['featuredpage-setting'.$count.'_image']; echo $pgimg['url']; ?>" />
    </div><?php } ?>
    <div class="featured-cont-box">
    	<h3><?php the_title(); ?></h3>
        <p><?php echo wp_trim_words( get_the_content(), $complete['featured_excerpt'] ); ?></p>
        <?php if (!empty ($complete['featured_block_button'])) { ?>
                    <a href="<?php the_permalink(); ?>" class="sktmore"><?php $ftdbutton = html_entity_decode($complete['featured_block_button']); $ftdbutton = stripslashes($ftdbutton); echo do_shortcode($ftdbutton); ?></a>   
                    <?php } ?>
        </div>
</div>         
 	</div>
        <?php if($count % $classNo == 0) { ?>
        <div class="clear"></div>
        <?php } ?>
	<?php
	$count++;
	endwhile;
 endif;
}
 
?></div>
<div class="clear"></div>
      </div>
    </div>
    <!-- Featture Boxes Section End -->   
    <!-- Home Section 1 -->
	<?php if($complete['hide_boxes_section1'] == ''){?>    
    <section class="home1_section_area <?php if($complete['section1_bg_image']){ ?>home1_section_area_bg<?php } ?>" <?php if(!empty($complete['section1_bg_video'])){ ?>data-vidbg-bg="mp4: <?php $sec1bgvideo = $complete['section1_bg_video']; echo do_shortcode($sec1bgvideo); ?>" data-vidbg-options="loop: true, muted: true, overlay: false"<?php } ?>>
    	<div class="center">
            <div class="home_section1_content">
             	  <?php 
				  	$pagesetting1 = get_theme_mod( 'page-setting1');
					if ($pagesetting1 == '0'){
						echo '<div class="headingtitle headingleft"><h3 style="color:#3e3e3e;">Success Stories</h3></div><div class="clear"></div><div class="storiesblock"><a href="#"><div class="stories-thumb"><img src="'.get_template_directory_uri().'/images/stories1.jpg" /></div><div class="stories-title">Tax Planning</div></a><div class="stories-description">Praesent mollis non lorem at interdum. Cum sociis atoque penatibus et magnis dis parturient montes, culus mus. Nunc quis pretium elit, nec congue lacus.</div></div><div class="storiesblock"><a href="#"><div class="stories-thumb"><img src="'.get_template_directory_uri().'/images/stories2.jpg" /></div><div class="stories-title">100% Guaranteed</div></a><div class="stories-description">Praesent mollis non lorem at interdum. Cum sociis atoque penatibus et magnis dis parturient montes, culus mus. Nunc quis pretium elit, nec congue lacus.</div></div><div class="storiesblock"><a href="#"><div class="stories-thumb"><img src="'.get_template_directory_uri().'/images/stories3.jpg" /></div><div class="stories-title">24/7 availability</div></a><div class="stories-description">Praesent mollis non lorem at interdum. Cum sociis atoque penatibus et magnis dis parturient montes, culus mus. Nunc quis pretium elit, nec congue lacus.</div></div>';
					}
					else
					{
					$secone = new WP_Query('page_id='.$pagesetting1.'');
					while ($secone->have_posts()) : $secone->the_post();
					?>
					<?php the_content(); ?>
					<?php endwhile; wp_reset_postdata(); ?>
					<?php 
					}
					?> 
            </div>
        </div>
    </section>
    <?php } ?>
    <?php wp_reset_postdata(); ?>
    <!-- Home Section 1 -->
  </div>
</div>
<?php } ?>
        <div id="content">
            <div class="center">
                <div class="single_wrap">
                    <div class="single_post">
                        <?php if(have_posts()): ?><?php while(have_posts()): ?><?php the_post(); ?>
                        <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">  
                                    
                        <!--EDIT BUTTON START-->
                            <?php if ( is_user_logged_in() || is_admin() ) { ?>
                                    <div class="edit_wrap">
                            			<a href="<?php echo get_edit_post_link(); ?>">
                            				<?php _e('Edit','complete'); ?>
                                		</a>
                            		</div>
                            <?php } ?>
                        <!--EDIT BUTTON END-->
                        
                        <!--PAGE CONTENT START-->   
                        <div class="single_post_content">
                        
                                <!--THE CONTENT START-->
                                    <div class="thn_post_wrap">
                                    	<h1><?php the_title(); ?></h1>
                                        <?php the_content(); ?>
                                    </div>
                                        <div style="clear:both"></div>
                                    <div class="thn_post_wrap wp_link_pages">
                                        <?php wp_link_pages('<p class="pages"><strong>'.__('Pages:', 'complete').'</strong> ', '</p>', 'number'); ?>
                                    </div>
                                <!--THE CONTENT END-->
                        </div>
                        <!--PAGE CONTENT END--> 
                        </div>
                   <?php endwhile ?> 
                    </div>
                  <!--COMMENT START: Calling the Comment Section. If you want to hide comments from your posts, remove the line below-->     
                  <?php if (!empty ($complete['post_comments_id'])) { ?>
                      <div class="comments_template">
                          <?php comments_template('',true); ?>
                      </div>
                  <?php }?> 
                  <!--COMMENT END-->
                  
                  <?php endif ?>
                    </div>
                <!--PAGE END-->
                <!--SIDEBAR START--> 
                <?php get_sidebar('page'); ?>
                <!--SIDEBAR END-->
                    </div>
            </div>
    </div><!--layer_wrapper class END-->
<?php get_footer(); ?>