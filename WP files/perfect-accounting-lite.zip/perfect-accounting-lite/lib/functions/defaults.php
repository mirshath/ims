<?php
function complete_option_defaults() {
	$defaults = array(
		'converted' => '',
		'site_layout_id' => 'site_full',
		'single_post_layout_id' => 'single_layout1',
		'header_layout_id' => 'header_layout1',
		'center_width' => 83.50,
		'content_bg_color' => '#ffffff',
		'divider_icon' => 'fa-stop',
		'head_transparent' => '',
		'trans_header_color' => '#fff',
		'totop_id' => '1',
		'footer_text_id' => __('Copyright 2017 All Rights Reserved | SKT Perfect Accounting Lite', 'complete'),
		'top_left_text_box' => __('<i class="fa fa-map-marker"></i>Company inc. 16 Surinamestraat, Netherlands', 'complete'),
		'phntp_text_id' => __('<i class="fa fa-phone"></i><a href="tel:+12(34)567-8988">+12(34)567-8988</a>', 'complete'),
		'email_text_id' => __('<i class="fa fa-envelope"></i></i><a href="mailto:support@sitename.com">support@sitename.com</a>', 'complete'),
		'suptp_text' => __('[social_area]
    [social icon="facebook" link="#"]
    [social icon="twitter" link="#"]
    [social icon="google-plus" link="#"]	
    [social icon="linkedin" link="#"]
    [social icon="pinterest" link="#"]
[/social_area]', 'complete'),
		'footmenu_id' => '1',
		'copyright_center' => '',
		
		'custom_slider' => '',
		
		'slider_type_id' => 'static',
		
		'slideefect' => 'fade',
		'slideanim' => '500',
		'slidepause' => '4000',
		'slidenav' => 'false',
		'slidepage' => 'true',
		
		'n_slide_time_id' => '6000',
		'slide_height' => '500px',
		'slidefont_size_id' => '36px',
		'slider_txt_hide' => '',

		'post_info_id' => '1',
		'post_nextprev_id' => '1',
		'post_comments_id' => '1',
		'page_header_color' => '#545556',
		'pageheader_bg_image' => '',
		'hide_pageheader' => '',
		'page_header_txtcolor' => '#555555',
		
		'post_header_color' => '#545556',
		'postheader_bg_image' => '',
		'hide_postheader' => '',		

		'blog_cat_id' => '',
		'blog_num_id' => '9',
		'blog_layout_id' => '',
		'show_blog_thumb' => '1',
		
		'sec_color_id' => '#fed100',
		'mnbg_color_id' => '#163651',
		'submnu_textcolor_id' => '#5d5d5c',
		'submnbg_color_id' => '#ffffff',
		'mnshvr_color_id' => '#163651',
		'mobbg_color_id' => '#383939',
		'mobbgtop_color_id' => '#fed100',
		'mobmenutxt_color_id' => '#FFFFFF',
		
		'mobtoggle_color_id' => '#000000',
		'mobtoggleinner_color_id' => '#FFFFFF',
		
		'sectxt_color_id' => '#FFFFFF',
		'content_font_id' =>  array('font-family' => 'Montserrat', 'font-size' => '13px'),
		'primtxt_color_id' => '#818282',
		'logo_image_id' => array(  'url'=>''.get_template_directory_uri().'/assets/images/logo.png'),
		'logo_font_id' => array('font-family' => 'Montserrat', 'font-size' => '27px'),
		'logo_color_id' => '#797978',
		
		'logo_image_height' => '29px;',
		'logo_image_width' => '186px;',
		'logo_margin_top' => '35px;',
		
		'tpbt_font_id' => array('font-family' => 'Montserrat', 'font-size' => '13px'),
		'tpbt_color_id' => '#ffffff',
		'tpbt_icon_color_id' => '#fed100',
		'tpbt_linkcolor_id' => '#ffffff',
		'tpbt_hvcolor_id' => '#fed100',	
		
		'sldtitle_font_id' => array('font-family' => 'Montserrat', 'font-size' => '52px'),
		'slddesc_font_id' => array('font-family' => 'Montserrat', 'font-size' => '15px'),
		'sldbtn_font_id' => array('font-family' => 'Montserrat', 'font-size' => '14px'),
		
		'slidetitle_color_id' => '#163651',	
		'slddesc_color_id' => '#252626',	
		'sldbtntext_color_id' => '#393a3a',
		'sldbtn_color_id' => '#fed100',
		'sldbtn_hvcolor_id' => '#ffffff',	
		
		'slide_pager_color_id' => '#163651',	
		'slide_active_pager_color_id' => '#fed100',	
		
			
		'global_link_color_id' => '#fed100',
		'global_link_hvcolor_id' => '#fed100',		
		
		'post_meta_color_id' => '#282828',
		'team_box_color_id' => '#fed100',
		
		'social_text_color_id' => '#ffffff',
		'social_icon_color_id' => '#d4d3d3',
		'social_hover_icon_color_id' => '#fed100',
		
		'head_bg_trans' => '0.4',
		'head_color_id' => '#fbfbfb',
		'head_info_color_id' => '#163651',
		'header_border_color' => '#dddddd',
		'menutxt_color_id' => '#5d5d5c',
		'menutxt_color_hover' => '#fed100',
		'menutxt_color_active' => '#fed100',
		'menu_size_id' => '14px',
		'sidebar_color_id' => '#FFFFFF',
		'sidebarborder_color_id' => '#eeeff5',
		'sidebar_tt_color_id' => '#666666',
		'sidebartxt_color_id' => '#999999',
		'global_link_hvcolor_id' => '#f26522',
		'sidebarlink_color_id' => '#fed100',
		'sidebarlink_hover_color_id' => '#999999',
 		
		'style3_bg_color' => '#ffffff',
		'style3_hover_bg_color' => '#9f9f9f',
		'style3_border_color' => '#fed100',
		
		'perfect_bg_color' => '#ffffff',
		'perfect_border_color' => '#eaeaea',
		'perfect_hover_border_color' => '#fed100',
		
		'story_block_bg_color' => '#ffffff',
		'story_title_color' => '#fed100',
		'story_title_bg_color' => '#002e5b',
		'story_title_hover_color' => '#163651',
		'story_title_hover_bg_color' => '#fed100',
		'story_desc_color' => '#818282',
 
		'foot_layout_id' => '3',
		'footer_color_id' => '#252525',
		'footwdgtxt_color_id' => '#929292',
		'footer_title_color' => '#ffffff',
		'ptitle_font_id' =>  array('font-family' => 'Montserrat', 'subsets'=>'latin'),
		'mnutitle_font_id' =>  array('font-family' => 'Montserrat', 'subsets'=>'latin'),
		'title_txt_color_id' => '#666666',
		'link_color_id' => '#3590ea',
		'link_color_hover' => '#1e73be',
		'txt_upcase_id' => '',
		'mnutxt_upcase_id' => '1',
		'copyright_bg_color' => '#222222',
		'copyright_txt_color' => '#929292',
		
		//Footer Info Box
		'footer_info_bgcolor' => '#161616',
		'footer_info_iconcolor' => '#ffffff',
		'footer_info_titlecolor' => '#ffffff',
		'footer_info_desccolor' => '#757575',
		'footer_info_shrtcolor' => '#00baff',
		'footer_info_dividercolor' => '#1f1f1f',		
		
		//Featured Box
		//'featured_section_title' => __('Featured Boxes', 'complete'),
		'homeblock_bg_setting' => '',
		'ftd_bg_video' => '',
		'homeblock_title_color' => '#000000',
		'homeblock_color_id' => '#ffffff',
		'featured_image_height' => '50px;',
		'featured_image_width' => '50px;',
		'featured_excerpt' => '25',
		'featured_block_bg' => '#163651',
		'featured_block_hvr_bg' => '#fed100',
		'featured_block_box_bg' => '#ffffff',
		'featured_block_titlecolor' => '#163651',
		'featured_block_title_hvcolor' => '#fed100',
		'featured_block_color' => '#818282',
		'featured_block_hovercolor' => '#ffffff',
		'featured_block_border' => '#fed100',
		'featured_block_hvborder' => '#ffc0d1',

		
		'featured_block_button' => __('READ MORE', 'complete'),
		'recentpost_block_button' => __('Read More', 'complete'),
		
		'featured_block_button_bg' => '#002e5b',
		'featured_block_hover_button_bg' => '#fed100',
		
		'featuredpage-setting1_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon1.png'),
		'featuredpage-setting2_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon2.png'),
		'featuredpage-setting3_image' => array(  'url'=>''.get_template_directory_uri().'/images/featured_icon3.png'),
		
		'featuredpage-setting1' => '0',
		'featuredpage-setting2' => '0',
		'featuredpage-setting3' => '0',
		'hide_boxes' => '',		
		
		
		'page-setting1' => '0',
		'page-setting2' => '0',
		'hide_boxes' => '',
		
		//Home Section1
		'section1_bgcolor_id' => '#fbfbfb',
		'section1_bg_image' => '',
		'section1_bg_video' => '',
		'hide_boxes_section1' => '',
		//Home Section1
		
 		'header_bg_color' => '#ffffff',
		'header_bg_image' => '',												
		
		
		//Footer Column 1
		'foot_cols1_title' => __('About Us', 'complete'),
		'foot_cols1_content' => '<p>Praesent mollis non lorem at interdum. Cum sociis natoque penatibus et magnis dis parturient montes, cetur ridiculus mus. Nunc quis pretium elit, nec congue lacus. Curabitur placerat diam risus, eget imperdiet dolor commodo pellentesque. Cras eleifend odio vel mauris interdum vulputate.</p><p>feugiat erat metus vel lacus. Nullam mollis turpis nunc. Suspendisse facilisis eleifend velit ac fringilla feugiat erat metus vel lacus. Nullam mollis turpis nunc. Suspendisse facilisis eleifend velit ac fringilla</p>[social_area]
    [social icon="facebook" link="#"]
    [social icon="twitter" link="#"]
    [social icon="google-plus" link="#"]	
    [social icon="linkedin" link="#"]
    [social icon="pinterest" link="#"]
[/social_area]',
		//Footer Column 1	
		
		//Footer Column 2
		'foot_cols2_title' => __('Latest News', 'complete'),
		'foot_cols2_content' => '[footerposts show="3"]',
		//Footer Column 2	
		
		//Footer Column 3
		'foot_cols3_title' => __('Business Hours', 'complete'),
		'foot_cols3_content' => '[timing icons="fa fa-clock-o" classname="Monday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Tuesday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Wednesday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Thursday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Friday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Saturday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Sunday" classtime="Closed"]',
		//Footer Column 3
		
		//Footer Column 4
		'foot_cols4_title' => __('Quick Contact', 'complete'),
		'foot_cols4_content' => '<p>Praesent nec dictum dolor, eget faucibus neque. Curabitur ac dolor a eros malesuadaing.<br><br> Phone: 1.800.555.6789<br> Email: <a href="mailto:demo@lorem.com">demo@lorem.com</a><br> Web: <a href="http://www.demo.com">demo.com</a></p>',
		//Footer Column 4																
		'social_button_style' => 'simple',
		'social_show_color' => '',
		'social_bookmark_pos' => 'footer',
		'social_bookmark_size' => 'normal',
		'social_single_id' => '1',
		'social_page_id' => '',
		
		//Footer Info Box 1
		'foot_infobox1_heading' => __('VISIT US', 'complete'),
		'foot_infobox1_icon' => '<i class="fa fa-map-o" aria-hidden="true"></i>',
		'foot_infobox1_description' => 'Aliquam porta tincidunt enim.',
		
		//Footer Info Box 2
		'foot_infobox2_heading' => __('EMAIL US', 'complete'),
		'foot_infobox2_icon' => '<i class="fa fa-envelope-o" aria-hidden="true"></i>',
		'foot_infobox2_description' => 'info@sitename.com',
		
		//Footer Info Box 3
		'foot_infobox3_heading' => __('CALL US', 'complete'),
		'foot_infobox3_icon' => '<i class="fa fa-phone" aria-hidden="true"></i>',
		'foot_infobox3_description' => '987 685 4528',
		
		'hide_foot_infobox' => '',
		
		'post_lightbox_id' => '1',
		'post_gallery_id' => '1',
		'cat_layout_id' => '4',
		'hide_mob_slide' => '',
		'hide_mob_rightsdbr' => '',
		'hide_mob_page_header' => '1',
		'custom-css' => '',
	);
	
      $options = get_option('complete',$defaults);

      //Parse defaults again - see comments
      $options = wp_parse_args( $options, $defaults );

	return $options;
}?>