<?php
//----------------------Footer Columns 1----------------------------------
	$wp_customize->add_setting('complete[foot_cols1_title]', array(
		'type' => 'option',
		'default'	=> __('About Us','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_cols1_title', array( 
		'type' => 'text',
		'label'	=> __('Columns 1 Title','complete'),
		'section' => 'footer_columns_section',
		'settings' => 'complete[foot_cols1_title]',
	)) );	
	
$wp_customize->add_setting('complete[foot_cols1_content]', array(
	'type' => 'option',
	'default' => '<p>Praesent mollis non lorem at interdum. Cum sociis natoque penatibus et magnis dis parturient montes, cetur ridiculus mus. Nunc quis pretium elit, nec congue lacus. Curabitur placerat diam risus, eget imperdiet dolor commodo pellentesque. Cras eleifend odio vel mauris interdum vulputate.</p><p>feugiat erat metus vel lacus. Nullam mollis turpis nunc. Suspendisse facilisis eleifend velit ac fringilla feugiat erat metus vel lacus. Nullam mollis turpis nunc. Suspendisse facilisis eleifend velit ac fringilla</p>[social_area]
    [social icon="facebook" link="#"]
    [social icon="twitter" link="#"]
    [social icon="google-plus" link="#"]	
    [social icon="linkedin" link="#"]
    [social icon="pinterest" link="#"]
[/social_area]',
	'sanitize_callback' => 'wp_kses_post',
	'transport' => 'postMessage',
) );
			$wp_customize->add_control(	new complete_Editor_Control( $wp_customize, 'foot_cols1_content', array( 
				'type' => 'editor',
				'label' => __('Columns 1 Content','complete'), 
				'section' => 'footer_columns_section',
				'settings' => 'complete[foot_cols1_content]',
			)) );	
 	 
//----------------------Footer Columns 1----------------------------------		

//----------------------Footer Columns 2----------------------------------
	$wp_customize->add_setting('complete[foot_cols2_title]', array(
		'type' => 'option',
		'default'	=> __('Latest News','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_cols2_title', array( 
		'type' => 'text',
		'label'	=> __('Columns 2 Title','complete'),
		'section' => 'footer_columns_section',
		'settings' => 'complete[foot_cols2_title]',
	)) );	
	
$wp_customize->add_setting('complete[foot_cols2_content]', array(
	'type' => 'option',
	'default' => '[footerposts show="3"]',
	'sanitize_callback' => 'wp_kses_post',
	'transport' => 'postMessage',
) );
			$wp_customize->add_control(	new complete_Editor_Control( $wp_customize, 'foot_cols2_content', array( 
				'type' => 'editor',
				'label' => __('Columns 2 Content','complete'), 
				'section' => 'footer_columns_section',
				'settings' => 'complete[foot_cols2_content]',
			)) );	
 	 
//----------------------Footer Columns 2----------------------------------	

//----------------------Footer Columns 3----------------------------------
	$wp_customize->add_setting('complete[foot_cols3_title]', array(
		'type' => 'option',
		'default'	=> __('Business Hours','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_cols3_title', array( 
		'type' => 'text',
		'label'	=> __('Columns 3 Title','complete'),
		'section' => 'footer_columns_section',
		'settings' => 'complete[foot_cols3_title]',
	)) );	
	
$wp_customize->add_setting('complete[foot_cols3_content]', array(
	'type' => 'option',
	'default' => '[timing icons="fa fa-clock-o" classname="Monday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Tuesday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Wednesday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Thursday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Friday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Saturday" classtime="9am - 12pm"][timing icons="fa fa-clock-o" classname="Sunday" classtime="Closed"]',
	'sanitize_callback' => 'wp_kses_post',
	'transport' => 'postMessage',
) );
			$wp_customize->add_control(	new complete_Editor_Control( $wp_customize, 'foot_cols3_content', array( 
				'type' => 'editor',
				'label' => __('Columns 3 Content','complete'), 
				'section' => 'footer_columns_section',
				'settings' => 'complete[foot_cols3_content]',
			)) );	
 	 
//----------------------Footer Columns 3----------------------------------	

//----------------------Footer Columns 4----------------------------------
	$wp_customize->add_setting('complete[foot_cols4_title]', array(
		'type' => 'option',
		'default'	=> __('Quick Contact','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_cols4_title', array( 
		'type' => 'text',
		'label'	=> __('Columns 4 Title','complete'),
		'section' => 'footer_columns_section',
		'settings' => 'complete[foot_cols4_title]',
	)) );	
	
$wp_customize->add_setting('complete[foot_cols4_content]', array(
	'type' => 'option',
	'default' => '<p>Praesent nec dictum dolor, eget faucibus neque. Curabitur ac dolor a eros malesuadaing.<br><br> Phone: 1.800.555.6789<br> Email: <a href="mailto:demo@lorem.com">demo@lorem.com</a><br> Web: <a href="http://www.demo.com">demo.com</a></p>',
	'sanitize_callback' => 'wp_kses_post',
	'transport' => 'postMessage',
) );
			$wp_customize->add_control(	new complete_Editor_Control( $wp_customize, 'foot_cols4_content', array( 
				'type' => 'editor',
				'label' => __('Columns 4 Content','complete'), 
				'section' => 'footer_columns_section',
				'settings' => 'complete[foot_cols4_content]',
			)) );	
 	 
//----------------------Footer Columns 4----------------------------------	



//----------------------Footer Info Box ----------------------------------
	$wp_customize->add_setting('complete[foot_infobox1_heading]', array(
		'type' => 'option',
		'default'	=> __('VISIT US','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox1_heading', array( 
		'type' => 'text',
		'label'	=> __('Column 1 Heading','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox1_heading]',
	)) );
	
	$wp_customize->add_setting('complete[foot_infobox1_icon]', array(
		'type' => 'option',
		'default'	=> __('<i class="fa fa-map-o" aria-hidden="true"></i>','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox1_icon', array( 
		'type' => 'text',
		'label'	=> __('Column 1 Icon','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox1_icon]',
	)) );	
	
	$wp_customize->add_setting('complete[foot_infobox1_description]', array(
		'type' => 'option',
		'default'	=> __('Aliquam porta tincidunt enim.','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox1_description', array( 
		'type' => 'textarea',
		'label'	=> __('Column 1 Description','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox1_description]',
	)) );
	
	
	
	$wp_customize->add_setting('complete[foot_infobox2_heading]', array(
		'type' => 'option',
		'default'	=> __('EMAIL US','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox2_heading', array( 
		'type' => 'text',
		'label'	=> __('Column 2 Heading','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox2_heading]',
	)) );
	
	$wp_customize->add_setting('complete[foot_infobox2_icon]', array(
		'type' => 'option',
		'default'	=> __('<i class="fa fa-envelope-o" aria-hidden="true"></i>','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox2_icon', array( 
		'type' => 'text',
		'label'	=> __('Column 2 Icon','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox2_icon]',
	)) );	
	
	$wp_customize->add_setting('complete[foot_infobox2_description]', array(
		'type' => 'option',
		'default'	=> __('info@sitename.com','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox2_description', array( 
		'type' => 'textarea',
		'label'	=> __('Column 2 Description','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox2_description]',
	)) );	
	
	$wp_customize->add_setting('complete[foot_infobox3_heading]', array(
		'type' => 'option',
		'default'	=> __('CALL US','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox3_heading', array( 
		'type' => 'text',
		'label'	=> __('Column 3 Heading','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox3_heading]',
	)) );
	
	$wp_customize->add_setting('complete[foot_infobox3_icon]', array(
		'type' => 'option',
		'default'	=> __('<i class="fa fa-phone" aria-hidden="true"></i>','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox3_icon', array( 
		'type' => 'text',
		'label'	=> __('Column 3 Icon','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox3_icon]',
	)) );	
	
	$wp_customize->add_setting('complete[foot_infobox3_description]', array(
		'type' => 'option',
		'default'	=> __('987 685 4528','complete'),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	) );
	$wp_customize->add_control(	new WP_Customize_Text_Control( $wp_customize, 'foot_infobox3_description', array( 
		'type' => 'textarea',
		'label'	=> __('Column 3 Description','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[foot_infobox3_description]',
	)) );	
	
	
// Hide Section
	$wp_customize->add_setting('complete[hide_foot_infobox]',array(
			'type' => 'option',
			'default' => '',
			'sanitize_callback' => 'complete_sanitize_checkbox',
			'transport' => 'postMessage',
	));	 

	$wp_customize->add_control( new complete_Controls_Toggle_Control( $wp_customize, 'hide_foot_infobox', array(
		'label' => __('Hide This Section','complete'),
		'section' => 'footer_infobox_section',
		'settings' => 'complete[hide_foot_infobox]',
	)) );	