/*-----------------------------------------------------------------------------------*/
/* SKT Bizness Responsive WordPress Theme */
/*-----------------------------------------------------------------------------------*/

Theme Name      :   SKT Bizness
Theme URI       :   https://www.sktthemes.org/shop/bizness/
Version         :   1.7
Tested up to    :   6.5
Author          :   SKT Themes
Author URI      :   https://www.sktthemes.org/

license         :   GNU General Public License v3.0
License URI     :   http://www.gnu.org/licenses/gpl.html

/*-----------------------------------------------------------------------------------*/
/* About Author - Contact Details */
/*-----------------------------------------------------------------------------------*/

email       :   support@sktthemes.com

/*-----------------------------------------------------------------------------------*/
/* Theme Resources */
/*-----------------------------------------------------------------------------------*/

Theme is Built using the following resource bundles.

1 - Open Sans font - https://www.google.com/fonts/specimen/Open+Sans
	License: Distributed under the terms of the Apache License, version 2.0 http://www.apache.org/licenses/LICENSE-2.0.html

2 - Social icons - We have used icons from http://genericons.com/

3 - Slider Images
		https://pxhere.com/en/photo/764432
		https://pxhere.com/en/photo/911155
		
	Images used from pxhere.com
		This site provides images under CC0 license
 		CC0 license: https://creativecommons.org/share-your-work/public-domain/cc0 		
		
## Copyrights for Resources used in this theme.

  All js that have been used are within folder /js of theme.
  - jquery.nivo.slider.js is licensed under MIT.
  - html5.js is dual licensed under MIT and GPL2
		

For any help you can mail us at support[at]sktthemes.com