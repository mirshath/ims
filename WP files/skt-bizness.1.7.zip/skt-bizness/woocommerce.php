<?php get_header(); ?>
<div class="content-area">
    <div class="container main_content_wrap">
      <div class="page_wrapper">  
                
        <section id="site-main" class="site-main" > 
			<?php woocommerce_content(); ?>
		    </section>
         <div class="clear"></div>
      </div><!--end .page_wrapper-->       
    </div>
</div>	
     
<?php get_footer(); ?>